# Phase 4 결과 요약 (수정 적용 확인 후 재실행)

## 실험 조건
- 환경: Unitree-Go2-Flat (Native-Electric vs Coupled-Electric)
- Seeds: 2 (7, 123)
- MuJoCo 수정: 전략 D (dynprm[1,2] 분기, Schur complement)
- Phase 3 검증: dt=0.1ms에서 전류 오차 비율 19.0x 확인 후 실행
- dt=0.1ms, decimation=50, policy dt=5ms, num_envs=4096
- 2000 iterations, GPU RTX 5080

## 최종 성능 (마지막 100 iterations 평균)

| Metric | filterexact | coupled | p-value |
|--------|------------|---------|---------|
| Mean Reward | 54.15 ± 0.16 | 54.37 ± 0.05 | 0.3079 |
| Mean Ep Length | 3955 ± 10.7 | 3972 ± 1.8 | 0.2618 |

### 개별 seed 결과

| Seed | native reward | coupled reward | native ep_len | coupled ep_len |
|------|--------------|----------------|---------------|----------------|
| 123  | 54.55        | 54.95          | 3973          | 3987           |
| 7    | 52.73        | 54.66          | 3870          | 4000           |

## 학습 곡선
![Learning Curves](learning_curves.png)

## 해석

p > 0.05로 통계적 유의성은 없으나, 이전 결과(수정 미적용)와 달리 **일관된 경향**이 관찰됨:
- coupled이 두 seed 모두에서 reward 우세 (+0.40, +1.93)
- coupled seed7의 ep_len=4000 (에피소드 전체 생존 = 최대값)
- native seed7만 reward 52.73으로 낮음 (ep_len=3870, 간헐적 낙하)

2 seeds로는 통계적 결론이 어려움. **seed 추가 시 시나리오 B 또는 C로 전환될 가능성 있음.**

## 이전 실행(수정 미적용)과의 비교

| | 이전 (4/2, 수정 미적용) | 이번 (4/7, 수정 적용) |
|---|---|---|
| native reward | 54.20 ± 0.22 | 54.15 ± 0.16 |
| coupled reward | 54.32 ± 0.20 | 54.37 ± 0.05 |
| 차이 | +0.12 (무의미) | +0.22 (일관된 경향) |
| coupled 우세 비율 | 확인 불가 (동일 코드) | 2/2 seeds |

이전에는 두 환경이 동일한 코드를 실행했으므로 차이가 없는 것이 당연했음.
이번에는 수정이 적용된 상태에서 실행되었으며, 작지만 일관된 차이가 관찰됨.

## 결론

**시나리오 A~B 경계**: 통계적 유의성은 미달이나, 수정 적용 전/후 결과 패턴이 다름.
- 수정 미적용: 완전히 동일 (당연)
- 수정 적용: coupled이 일관적으로 우세 (p=0.31, n=2)

seed 3~5개 추가 실험으로 확정 가능.
